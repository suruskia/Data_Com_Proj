#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <windows.h>  // Windows thread support
#include <time.h>
#include <direct.h>  // For creating directories 
#define MAX_CLIENTS 10
#define LOG_DIR "logs"

struct Client {
    int socket;
    char username[256];
};

struct Client clients[MAX_CLIENTS];
int client_count = 0;
HANDLE client_threads[MAX_CLIENTS];

void error(const char *msg, ...);
DWORD WINAPI handle_client(LPVOID client_data);
void send_private_message(const char *message, const char *recipient, const char *sender_username, int sender_socket);
void broadcast_message(const char *message, const char *sender_username, int sender_socket);
void remove_client(int socket);
void log_private_message(const char *sender_username, const char *recipient, const char *message);
void log_public_message(const char *sender_username, const char *message);
void create_logs_directory();

int main(int argc, char *argv[]) {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        fprintf(stderr, "Failed to initialize Winsock\n");
        exit(1);
    }//Ensures the application can use TCP/IP sockets and Initializes the Winsock .

    if (argc < 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        exit(1);
    }

    // Create the logs directory if it doesn't exist
    create_logs_directory();

    int sockfd = socket(AF_INET , SOCK_STREAM, 0); //creating TCP socket IPV4
    if (sockfd == INVALID_SOCKET) {
        error("ERROR opening socket");
    }

    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(serv_addr));
    int portno = atoi(argv[1]);

    serv_addr.sin_family = AF_INET; //IPV4
    serv_addr.sin_addr.s_addr = INADDR_ANY; //store server IP adress
    serv_addr.sin_port = htons(portno); // convert port num to network byte

    if (bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == SOCKET_ERROR) {
        error("ERROR on binding");
    }

    listen(sockfd, 5); // server in listening mode
    printf("Server started on port %d\n", portno);

    while (1) {
        struct sockaddr_in cli_addr;
        int clilen = sizeof(cli_addr);
        SOCKET newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);//Accepts an incoming client connection and returns a new socket
        if (newsockfd == INVALID_SOCKET) {
            error("ERROR on accept");
        }

        if (client_count >= MAX_CLIENTS) {
            closesocket(newsockfd);
            continue;
        }

        struct Client *client = &clients[client_count];
        client->socket = newsockfd;
        recv(client->socket, client->username, sizeof(client->username), 0);
        printf("New client connected: %s\n", client->username);

        client_threads[client_count] = CreateThread(NULL, 0, handle_client, (LPVOID)client, 0, NULL);
        client_count++;
    }

    closesocket(sockfd);
    WSACleanup();
    return 0;
}

DWORD WINAPI handle_client(LPVOID client_data) {
    struct Client *client = (struct Client *)client_data;
    char buffer[512];
    
    while (1) {
        memset(buffer, 0, sizeof(buffer));
        int n = recv(client->socket, buffer, sizeof(buffer) - 1, 0);
        if (n <= 0) {
            printf("Client %s disconnected\n", client->username);
            break;
        }

        // If the message starts with '@', it's a private message
        if (buffer[0] == '@') {
            // Private message
            char recipient[256];
            char message[256];
            if (sscanf(buffer, "@%s %[^\n]", recipient, message) == 2) {
                log_private_message(client->username, recipient, message);
                send_private_message(message, recipient, client->username, client->socket);
            } else {
                printf("Error parsing private message: %s\n", buffer);
            }
        } else {
            // Public message (broadcast to all clients except the sender)
            log_public_message(client->username, buffer);
            broadcast_message(buffer, client->username, client->socket);
        }
    }
    remove_client(client->socket);
    return 0;
}

void send_private_message(const char *message, const char *recipient, const char *sender_username, int sender_socket) {
    int found = 0;
    for (int i = 0; i < client_count; ++i) {
        if (strcmp(clients[i].username, recipient) == 0) {
            char private_message[512];
            sprintf(private_message, "[Private] %s: %s", sender_username, message);
            send(clients[i].socket, private_message, strlen(private_message), 0);
            found = 1;
            break;
        }
    }
    if (!found) {
        const char *error_msg = "Error: Recipient not found or offline.\n";
        send(sender_socket, error_msg, strlen(error_msg), 0);
    }
}

void broadcast_message(const char *message, const char *sender_username, int sender_socket) {
    char broadcast_msg[512];
    snprintf(broadcast_msg, sizeof(broadcast_msg), "[Public] %s: %s", sender_username, message);

    // Send the message to all clients except the sender
    for (int i = 0; i < client_count; ++i) {
        // Don't send the message back to the client who sent it
        if (clients[i].socket != sender_socket) {
            send(clients[i].socket, broadcast_msg, strlen(broadcast_msg), 0);
        }
    }

    // Log the public message to the server console
    printf("[Public] %s: %s\n", sender_username, message);
}

void remove_client(int socket) {
    for (int i = 0; i < client_count; ++i) {
        if (clients[i].socket == socket) {
            for (int j = i; j < client_count - 1; ++j) {
                clients[j] = clients[j + 1];
            }
            client_count--;
            break;
        }
    }
}

void log_private_message(const char *sender_username, const char *recipient, const char *message) {
    // Log private messages to a log file inside the 'logs' directory
    char log_path[512];
    snprintf(log_path, sizeof(log_path), "%s/private_messages.log", LOG_DIR);

    FILE *log_file = fopen(log_path, "a");
    if (log_file) {
        fprintf(log_file, "[Private] %s to %s: %s\n", sender_username, recipient, message);
        fclose(log_file);
    }
}

void log_public_message(const char *sender_username, const char *message) {
    // Log public messages to a log file inside the 'logs' directory
    char log_path[512];
    snprintf(log_path, sizeof(log_path), "%s/public_messages.log", LOG_DIR);

    FILE *log_file = fopen(log_path, "a");
    if (log_file) {
        fprintf(log_file, "[Public] %s: %s\n", sender_username, message);
        fclose(log_file);
    }
}

void create_logs_directory() {
    // Create the 'logs' directory if it doesn't exist
    if (_mkdir(LOG_DIR) == 0) {
        printf("Created logs directory\n");
    } else {
        printf("Logs directory already exists\n");
    }
}

void error(const char *msg, ...) {
    va_list args;
    va_start(args, msg);
    vfprintf(stderr, msg, args);
    va_end(args);
    fprintf(stderr, ": %d\n", WSAGetLastError());
    exit(1);
}

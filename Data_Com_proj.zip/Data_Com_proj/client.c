#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <windows.h>  // For threading support
#include <time.h>
#include <stdint.h>
#include <direct.h>

#pragma comment(lib, "ws2_32.lib")

DWORD WINAPI socket_reader(LPVOID param);

int main(int argc, char *argv[]) {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        fprintf(stderr, "Failed to initialize Winsock\n");
        exit(1);
    }

    if (argc < 4) {
        fprintf(stderr, "Usage: %s <hostname> <port> <username>\n", argv[0]);
        WSACleanup();
        exit(1);
    }

    SOCKET sockfd;
    struct sockaddr_in serv_addr;
    char buffer[512];

    int portno = atoi(argv[2]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == INVALID_SOCKET) {
        fprintf(stderr, "ERROR opening socket\n");
        exit(1);
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(portno);

    serv_addr.sin_addr.s_addr = inet_addr(argv[1]);
    if (serv_addr.sin_addr.s_addr == INADDR_NONE) {
        fprintf(stderr, "Invalid address/Address not supported\n");
        closesocket(sockfd);
        WSACleanup();
        exit(1);
    }

    if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == SOCKET_ERROR) {
        fprintf(stderr, "ERROR connecting\n");
        exit(1);
    }

    // Send username to the server
    send(sockfd, argv[3], strlen(argv[3]), 0);

    // Start a thread to read incoming messages
    CreateThread(NULL, 0, socket_reader, (LPVOID)&sockfd, 0, NULL);

    // Input loop to send private or public messages
    while (1) {
        memset(buffer, 0, sizeof(buffer));
        if (fgets(buffer, sizeof(buffer) - 1, stdin) != NULL) {
            // If the message starts with '@', it's a private message
            if (buffer[0] == '@') {
                send(sockfd, buffer, strlen(buffer), 0);
            } else {
                // Otherwise, it's a public message
                send(sockfd, buffer, strlen(buffer), 0);
            }
        }
    }

    closesocket(sockfd);
    WSACleanup();
    return 0;
}

DWORD WINAPI socket_reader(LPVOID param) {
    SOCKET sockfd = *(SOCKET*)param;
    char buffer[512];

    while (1) {
        memset(buffer, 0, sizeof(buffer));
        int n = recv(sockfd, buffer, sizeof(buffer) - 1, 0);
        if (n <= 0) {
            printf("Disconnected from server.\n");
            break;
        }
        printf("%s\n", buffer);
    }
    return 0;
}
